//	Brian L. McMichael - Project 2

$(document).ready(function() {

	//$("#mainWindow").resizable({minWidth: 265});
	
	$(".window").draggable();
	
	$("#lotbeTrailerWindow").hide();
	$("#carnelianTrailerWindow").hide();
	$("#dhpTrailerWindow").hide();
	
	$("#openYoutubeVideo").click(function(event) {
		ie8SafePreventEvent(event);
		$("#lotbeTrailerWindow").show();
	});	
	$("#openYoutubeVideo2").click(function(event) {
		ie8SafePreventEvent(event);
		$("#carnelianTrailerWindow").show();
	});	
	$("#openYoutubeVideo3").click(function(event) {
		ie8SafePreventEvent(event);
		$("#dhpTrailerWindow").show();
	});
	
	$("#lotbeTop").click(function() {
		$("#lotbeTrailerWindow").hide();
	});
	$("#carnelianTop").click(function() {
		$("#carnelianTrailerWindow").hide();
	});
	$("#dhpTop").click(function() {
		$("#dhpTrailerWindow").hide();
	});
	
	$(".icon").draggable({containment: 'parent'});

	$(".icon").selectable();

	$("#desktopIcon").hide();
	$("#mainContentIcon").hide();	
	$("#nowContentIcon").hide();	
	$("#secondaryContentIcon").hide();

	$("#desktopIcon").dblclick(function() {
		$("#desktopIcon").toggle("puff", {}, 200);
		$("#mainWindow").toggle("scale", {}, 200);
	});

	function ie8SafePreventEvent(e){
    	if(e.preventDefault){ e.preventDefault()}
    	else{e.stop()};
    	e.returnValue = false;
    	e.stopPropagation();        
	}

	function contentToggler() {			
		$("#contentWindow").toggle("scale", {}, 200);		
		$("#projectContentWindow").toggle("scale", {}, 200);
		$("#aboutContentWindow").toggle("scale", {}, 200);
		$("#contactWindow").toggle("scale", {}, 200);
		$("#resumeWindow").toggle("scale", {}, 200);
	}

	$("#mainContentIcon").dblclick(function() {
		$("#mainContentIcon").toggle("puff", {}, 200);
		contentToggler();
	});
	
	$("#nowContentIcon").dblclick(function() {
		$("#nowContentIcon").toggle("puff", {}, 200);
		$("#nowWindow").toggle("scale", {}, 200);
	});	

	$("#secondaryContentIcon").dblclick(function() {
		$("#secondaryContentIcon").toggle("puff", {}, 200);
		$("#socialMediaWindow").toggle("scale", {}, 200);
	});

	$("#minMain").click(function() {
		$("#desktopIcon").toggle("puff", {}, 200);
		$("#mainWindow").toggle("scale", {}, 200);		
	});

	$("#minSecondary").click(function() {
		$("#secondaryContentIcon").toggle("puff", {}, 200);
		$("#socialMediaWindow").toggle("scale", {}, 200);		
	});

	$("#minMainContent").click(function() {
		$("#mainContentIcon").toggle("puff", {}, 200);
		contentToggler();		
	});
	
	$("#minNowContent").click(function() {
		$("#nowContentIcon").toggle("puff", {}, 200);
		$("#nowWindow").toggle("scale", {}, 200);
	});

	$("#shutdown").dblclick(function() {
		window.location.href = "shutdown.html";
	});
	
	//Just for fun
	var counter = 0;
	$("#welcome p").click(function() {
		counter++;
		if (counter < 8) {
			$("#hammertime").append("<img class='hammertime' src='img/mchammer.gif'>");
		} else if (counter == 8) {
			$("#hammertime").append("<p>You are too legit to quit.</p>");
		} else if (counter == 12) {
			$("#hammertime").append("<p>Too legit.</p>");
		}		
	});
});