//	Brian L. McMichael - Project 2

$(document).ready(function() {

	function blink() {
		$("#commandLine").effect("highlight", {color: "#FFFFFF"}, 1000);
	};

	setInterval(blink, 1000);

});
