//Brian L. McMichael Project 2

function validateForm() {
	if (document.forms[0].firstname.value == "" ) {
		alert("Please enter a first name.");
		return false;			
	} 
	if (document.forms[0].lastname.value == "" ) {
		alert("Please enter a last name.");
		return false;			
	} 
	if (document.forms[0].email.value == "" ) {
		alert("Please enter an email address.");
		return false;
	} 
	if (document.forms[0].email.value == "" ) {
		alert("Please enter an email address.");
		return false;
	} 
	if (document.forms[0].subject.value == "") {
		
		alert("Please enter a subject.");
		return false;
	} 
	return true;
}
