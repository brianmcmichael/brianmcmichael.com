<!DOCTYPE html>

<head>
	<meta http-equiv="content-type"
		content="text/html; charset=
		iso-8859-1" />
		
	<title>Calendar</title>
	
</head>
<body>
	<?php # Script 2.6 = calendar.php
	
		//This script makes three pull down menus
		//for an html form: months, days, years.
		
		//Make the months array:
		$months = array (1 => 'January', 'February',
			'March', 'April', 'May', 'June', 'July',
			'August', 'September', 'October', 'November',
			'December');
			
		//Make the days and years arrays:
		$days = range (1, 31);
		$years = range (2007, 2025);
		
		//Make the months pull down menu
		echo '<select name="month">';
		foreach ($months as $key => $value)
		{
			echo "<option value=\"$key\">$value</option>\n";
		}
		
		echo '</select>';
		
		//Make all the days pull down
		echo '<select name="day">';
		foreach ($days as $value)
		{
			echo "<option value=\"$value\">$value</option>\n";			
		}
		echo '</select>';
		
		//Make all the years pull down
		echo '<select name="year">';
		foreach ($years as $value)
		{
			echo "<option value=\"$value\">$value</option>\n";			
		}
		echo '</select>';
	
	?>
</body>
</html>