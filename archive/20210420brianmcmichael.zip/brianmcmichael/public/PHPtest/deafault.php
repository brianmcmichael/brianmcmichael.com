<!DOCTYPE html>

<head>
	<meta http-equiv="content-type"
		content="text/html; charset=
		iso-8859-1" />
		
	<title>Title</title>
	
</head>
<body>
	<?php 
	
	
	
	?>
</body>
</html>