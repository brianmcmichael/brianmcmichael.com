<!DOCTYPE html>

<head>
	<meta http-equiv="content-type"
		content="text/html; charset=
		iso-8859-1" />
		
	<title>Constants</title>
	
</head>
<body>
	<?php # Script 1.9 - constants.php
	
		define('TODAY', 'December 5, 2012');
		
		echo '<p>Today is ' . TODAY . '.<br />
			This server is running version <b>
			' . PHP_VERSION . ' </b> of PHP on
			the <b>' . PHP_OS . '</b> operating
			system.</p>';		
	
	?>
</body>
</html>