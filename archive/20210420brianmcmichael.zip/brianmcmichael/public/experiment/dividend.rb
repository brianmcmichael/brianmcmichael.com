
my_shares = 0
my_balance = 0
total_shares = 100000
SHARES_PER_ETH = 1000
INVESTMENT = 1
rand = Random.new

my_balance = -INVESTMENT
my_shares = INVESTMENT * SHARES_PER_ETH
total_shares = my_shares + total_shares
my_balance = (total_shares + my_shares) / INVESTMENT

puts "Beginning balance: #{my_balance}"



1000.times do |x|
  new_investment = rand.rand(1000)
  total_shares += new_investment * SHARES_PER_ETH
  my_balance += (new_investment / total_shares) * my_shares
  puts "Balance after #{x} turns: {my_balance} ETH"
end
